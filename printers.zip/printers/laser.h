#include<string>
using namespace std;
class laser:public printer
{
public:
 void printfiles(string);
};
