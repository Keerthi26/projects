#include<string>
using namespace std;
class file{
protected:
	string file_name;
	string file_type;
public:
	void filename(string);
	void filetype(string);
	virtual string getprintrepresentation(){return ""};
};
