#include<string>
using namespace std;
class printer{
private:
	string printer_name,printer_type,printer_colour;
public:
	void printername(string);
	void printertype(string);
	void printercolor(string);
	virtual void printfiles(string);
};
