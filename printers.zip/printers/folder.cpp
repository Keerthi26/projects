#include<iostream>
#include<string>

#include"folder.h"
#include<vector>
using namespace std;
void folder::add_files(file *f)
{
	Myfiles.push_back(f);
}
