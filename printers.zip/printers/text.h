#include<string>
using namespace std;
class text:public file
{
public:
	string getprintrepresentation();
};
