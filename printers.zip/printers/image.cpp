#include<iostream>
#include<string>
#include"image.h"
using namespace std;
string image::getprintrepresentation(){
	return "imagefile";
}
