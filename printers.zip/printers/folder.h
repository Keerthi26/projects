#include<vector>
#include<string>
#include"file.h"
using namespace std;
class folder{
private:
public:
	vector<file*>Myfiles;
	void add_files(file *);
};

