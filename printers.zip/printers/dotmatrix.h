#include<string>
using namespace std;
class dotmatrix:public printer
{
public:
 void printfiles(string);
};
