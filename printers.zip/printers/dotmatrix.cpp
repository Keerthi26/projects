#include<iostream>
#include"laser.h"
#include<string>
using namespace std;

