#include<iostream>
#include<string>
#include"printer.h"
using namespace std;
void printer::printername(string pn){
	printer_name=pn;
}
void printer ::printertype(string pt)
{
printer_type=pt;
}
void printer :: printercolor(string color)
{
printer_colour=color;
}
/*void printer::setdefault(string k)
{
printer_name=k;
cout<<"setting dfault printer to "<<printer_name<<endl;
}*/
