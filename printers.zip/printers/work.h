#include<vector>  
#include<string>
#include"file.h"
#include"printer.h"
using namespace std;
class work
{
private:
public:
file *fil;
printer *prn;
vector<file *>files;
vector<printer*>prints;
void scanning(string,string,string,string);
void pushfiles(file *);
void pushprints(printer *);
};
