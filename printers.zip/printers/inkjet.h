#include<string>
using namespace std;
class inkjet:public printer
{
public:
 void printfiles(string);
};
