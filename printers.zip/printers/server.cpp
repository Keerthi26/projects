#include<iostream>
#include<string>
#include<vector>
#include"server.h"
using namespace std;
void seerver::setofprinters(printer *pri)
{
  Myprinters.push_back(pri);
}

