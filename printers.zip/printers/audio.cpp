#include<iostream>
#include<string>
#include"audio.h"
using namespace std;
string audio::getprintrepresentation(){
	return NULL;
}
