#include<iostream>
#include<string>
#include<vector>
#include"work.h"
using namespace std;
void work :: scanning(string inp_name,string in_file,string in_color)
{
if(getline(cin,inp_name1))
{
inp_name1=setddefault(inp_name);
prn->printer1name(inp_name1);
prn->printer1color(in_color);
fil->file(in_file);
pushfiles(fil);
pushprints(prn);
}
else if(getline(cin,inp_name1) && getline(cin,in_color))
{
inp_name1=setdefault(inp_name);
in_color="COLOUR";
prn->printer1name(inp_name1);
prn->printer1color(in_color);
fil->file(in_file);
pushfiles(fil);
pushprints(prn);
}
else
{
prn->printer1name(inp_name1);
prn->printer1color(in_color);
fil->file(in_file);
pushfiles(file);
pushprints(prn);
}
}

void work::pushfiles(file *fil)
	{
	files.push_back(fil);
	}
void work::pushprints(printer *prn)
	{
	prints.push_back(prn);
	}


