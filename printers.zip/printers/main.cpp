#include<iostream>
#include "text.h"
#include "audio.h"
#include "image.h"
#include"folder.h"
#include<string>
#include"server.h"																																																																										
using namespace std;
int main()
{
folder fol;	
server ser;
file *f;
printer *pri;
	int noprinters,nofiles;
	cin>>noprinters;
	cout<<noprinters<<endl;
	string printer_color, printer_name,printer_type,print_type,file_name,file_type,printer_name1,folder,folder_name;
	string word,inp_name,in_file,in_color,inp_name1;
	for(int i=0;i<noprinters;i++)
		{
		pri=new printer;
		cin>>printer_name>>printer_type>>print_type;
		pri->printername(printer_name);
		pri->printertype(printer_type);
		pri->printercolor(print_type);
		ser.setofprinters(pri);
		}
	cin>>folder>>folder_name;
	cout<<folder<<folder_name;	
	cin>>nofiles;
	cout<<nofiles<<endl;
	for(int j=0;j<nofiles;j++)
		{
		f=new file;
		cin>>file_name>>file_type;
		f->filename(file_name);
		f->filetype(file_type);
		fol.add_files(f);
		}


cin >> word;
while(word!="END")
	{
	if(word=="SETDEFAULT")
	{
	cin>>inp_name;
	
	}
	else if(word=="PRINT")
	{
	cin >> in_file>>in_color>>inp_name1;
	
	}
}
}






















	
}
