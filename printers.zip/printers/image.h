#include<string>
using namespace std;
class image:public file
{
public:
	string getprintrepresentation();
};
