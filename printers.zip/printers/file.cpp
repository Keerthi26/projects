#include<iostream>
#include<string>
#include"file.h"
using namespace std;
void file::filename(string fn)
	{
	file_name=fn;
	}
void file::filetype(string ft)
	{
	file_type=ft;
	}

