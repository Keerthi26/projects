#include<string>
#include"printer.h"
#include<vector>
using namespace std;
class server{
public:
	vector<printer*>Myprinters;
	void setofprinters(printer *);

		
	
};
