#include<iostream>
#include<string>
#include"text.h"
using namespace std;
string text::getprintrepresentation(){
	return "textfile";
}
