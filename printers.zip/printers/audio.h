#include<string> 
using namespace std;
class audio:public file
{
public:
	string getprintrepresentation();
};
