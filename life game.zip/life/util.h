int nrowscols(char *,int *,int *);
int** create(int,int);
char** intialize(char**,int,int,char *);
void print(char**,int,int);
int** copygen(char** ,int,int);
int** reset(int,int);
int neighbourcount(char **,int,int,int,int);
int countneighbour(char **,int,int);
void newgenarr(char **,char **,int **,int,int,int);
void del1(int **,int,int);
void del2(char **,int,int);




