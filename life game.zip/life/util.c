#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int nrowscols(char *in,int *rows,int *cols)
	{
	FILE *fp;
	fp=fopen(in,"r");
	int count=0;
	char string[600];
	while(!feof(fp))
		{
        	fscanf(fp,"%s\n",string);
		count=count+1;
		}
	*rows=count;
	*cols=strlen(string);
	fclose(fp);
	return 0;
	}
char** create(int cols,int rows)
	{
	int i;
	char **matrix= (char**)malloc(sizeof(char *)*rows);
	for(i=0;i<rows;i++)
		matrix[i]= (char*)malloc(sizeof(char)*cols);
	return matrix;
	}
char** intialize(char** newgen,int cols,int rows,char *in)
	{
	int i,j;
	FILE *fp;
	fp=fopen(in,"r");
	for(i=0;i<rows;i++)
		{
		 for(j=0;j<cols;j++)
		 newgen[i][j]=fgetc(fp);
		}
	return newgen;
	fclose(fp);
	}
void print(char** newgen,int cols,int rows)
	{
	int i,j;
	for(i=0;i<rows;i++)
                {
			for(j=0;j<cols;j++)
                        printf("%c",newgen[i][j]);
		}
			printf("\n");
	}
char** copygen(char ** newgen,int cols,int rows)

        { 
	char **matrix1=(char**)malloc(sizeof(char *)*rows);
	int i,j;
        for(i=0;i<rows;i++)
                matrix1[i]=(char*)malloc(sizeof(char)*cols);
        for(i=0;i<rows;i++)
		{
			for(j=0;j<cols;j++)
				matrix1[i][j]==newgen[i][j];
		}
	return matrix1;
	}
int** reset(int rows,int cols)
	{
	int** matrix2=(int**)malloc(sizeof(int *)*rows);
	int i;
        for(i=0;i<rows;i++)
                matrix2[i]=(int*)malloc(sizeof(int)*cols);
	}
int neighbourcount(char **gen,int rIn,int cIn,int nRow,int nCol)
	{
	int count=0;
	if(rIn>0)
		{if(gen[rIn-1][cIn]!='.') 
			count++;}
        if(rIn<nRow-1)
		{if(gen[rIn+1][cIn]!='.') 
			count++;}
	
	if(cIn>0)
		{if(gen[rIn][cIn-1]!='.') 
			count++;}
	
	if(cIn<nCol-1)
		{if(gen[rIn][cIn+1]!='.') 
			count++;}
	
	if((rIn>0)&&(cIn>0))
		{if(gen[rIn-1][cIn-1]!='.') 
			count++;}
	
	if((rIn>0)&&(cIn<nCol-1))
		{if(gen[rIn-1][cIn+1]!='.') 
			count++;}
	
	if((rIn<nRow-1)&&(cIn<nCol-1))
		{if(gen[rIn+1][cIn+1]!='.') 
			count++;}
	
	if((rIn<nRow-1)&&(cIn>0))
		{if(gen[rIn+1][cIn-1]!='.') 
			count++;}
	return count;	
	}
int ** Countneighbour(char **array,int row,int column)
	{
	int i,j,nRow,nCol,k=0,**countneigh;
	countneigh=(int**)malloc(sizeof(int*)*row);
	for(k=0;k<row;k++)
		{
		countneigh[k]=(int*)malloc(sizeof(int*)*column);
		}
	for(i=0;i<row;i++)
		{
		for(j=0;j<column;j++)
			{
			countneigh[i][j]=neighbourcount(array,i,j,row,column);
			}
		}
	return countneigh;
	}
void newgenarr(char **matrix,char **generation1,int **generation,int num,int row,int column)
      {
      int n=1;
      int l,m;
      while(n<=num)
	{
	generation=Countneigh(matrix,row,column);
	printf("Generation%d:\n",n);
	int i=0,j=0,k=0;
	generation1=(char**)malloc(sizeof(char*)*(row+10));
	for(k=0;k<row;k++)
		{generation1[k]=(char*)malloc(sizeof(char)*(column+10));}
	for(i=0;i<row;i++)
	   {
	    for(j=0;j<column;j++)
	      {
	      if(matrix[i][j]!='.')
	       {	      
	       if(generation[i][j]<2 || generation[i][j]>3)
		{generation1[i][j]='.';}
	       else if(generation[i][j]==2 || generation[i][j]==3)
		{generation1[i][j]=matrix[i][j]-1;}
	       else
	       {generation1[i][j]=matrix[i][j];}
	       }
	      else
		{
		if(generation[i][j]==3)
			{generation1[i][j]='x';}
		else
			{generation1[i][j]=matrix[i][j];}
		}
	      printf("%c",generation1[i][j]);
	      }
	   printf("\n");
	 }

	}
    }
                            
void freeMatrix(char **matrix,int rows)
{
	int i=0;
	for(i=0;i<rows;i++)
		free(matrix[i]);
	free(matrix);
}

		



	

		


