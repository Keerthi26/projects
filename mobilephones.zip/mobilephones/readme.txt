COMPILATION COMMAND :
g++ main.cpp sim.cpp smartphone.cpp featurephone.cpp mobile.cpp manufacture.cpp modem.cpp network.cpp -o main

RUN COMMAND :
./main < input.txt
