//#include "mobile.h"
#include "featurephone.h"
class Smartphone : public Mobile 
{
	public:

		string CManufacturer;
		string CModelName;
		void ScanComputerPlatformDetails();
		string get_CManufacturer();
		string get_CModelName();

};