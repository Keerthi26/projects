#include "mobile.h"
class Featurephone : public Mobile
{
	public:
	
	
};