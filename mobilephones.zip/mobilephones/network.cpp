#include<iostream>
#include<string>
#include<vector>
#include"smartphone.h"
#include "network.h"
using namespace std;
void Network :: Add_Phone_To_Network()
{
	cin>>NumberOfPhones;
	for (int i=0; i<NumberOfPhones; i++)
	{
		cin>>TypeOfPhone;
		if(TypeOfPhone=='S')
		{
			Smartphone sp;
			sp.ma.ScanManufactureDetails();
			sp. ScanModelDetails();
			sp.ScanComputerPlatformDetails();
			sp.mo.ScanModemDetails();
			for(int k=0;k<sp.mo.NumModems;k++)
			{
				Sim s;
				s.Operator = " "; //default value empty string
				s.PhoneNumber = 0; //default value 0
				sp.si.push_back(s);
			}

			Smartphone *sph=new Smartphone(sp);
			mobi.push_back(sph);
				/*cout<<mobi[i]->ma.ManufacturerName<<" ";
				cout<<mobi[i]->ma.Country<<" ";
				cout<<mobi[i]->Model<<" ";
				cout<<mobi[i]->get_CManufacturer()<<" ";
				cout<<mobi[i]->get_CModelName()<<" ";
				cout<<mobi[i]->mo.ModemInfo<<" ";
				cout<<mobi[i]->mo.NumModems<<" ";
				for(int j=0;j<mobi[i]->mo.NumModems;j++)
				{
					cout<<mobi[i]->mo.v[j]<<" ";
				}
				cout << endl;*/
		}
		else if(TypeOfPhone=='F')
		{
			Featurephone fp;
			fp.ma.ScanManufactureDetails();
			fp. ScanModelDetails();
			fp.mo.ScanModemDetails();
			for(int k=0;k<fp.mo.NumModems;k++)
			{
				Sim s;
				s.Operator = " ";
				s.PhoneNumber = 0;
				fp.si.push_back(s);
			}

			Featurephone *fph = new Featurephone(fp);
			mobi.push_back(fph);
				/*cout<<mobi[i]->ma.ManufacturerName<<" ";
				cout<<mobi[i]->ma.Country<<" ";
				cout<<mobi[i]->Model<<" ";
				cout<<mobi[i]->mo.ModemInfo<<" ";
				cout<<mobi[i]->mo.NumModems<<" ";
				for(int j=0;j<mobi[i]->mo.NumModems;j++)
				{
					cout<<mobi[i]->mo.v[j]<<" ";
				}
				cout << endl;*/
		}
		
	}
	cin>>NumberOfSims;
	//cout<<NumberOfSims<<endl;
	for(int j=0;j<NumberOfSims;j++)
	{
		s.ScanSimValues();
		mobi[j]->si[0].Operator=s.Operator;
		mobi[j]->si[0].PhoneNumber=s.PhoneNumber;

		/*cout<<mobi[j]->si[0].Operator<<" ";
		cout<<mobi[j]->si[0].PhoneNumber;
		cout<<endl;*/
	}

}
void Network :: List_Manufacture_Details()
{
	for (int i=0; i<NumberOfPhones; i++)
	{
		cout<<mobi[i]->ma.ManufacturerName<<" ";
		cout<<mobi[i]->ma.Country<<" ";
		cout<<endl;
	}
} 
void Network :: Number_Of_Phones_With_Each_Modeminfo()
{
	countgsm=0;
	countgprs=0;
	countwcdma=0;
	countlte=0;	
	for (int i=0; i<NumberOfPhones; i++)
	{
		if(mobi[i]->mo.ModemInfo=="GSM")
		{
			countgsm=countgsm+1;
		}
		else if(mobi[i]->mo.ModemInfo=="GPRS")
		{
			countgprs=countgprs+1;
		}
		else if(mobi[i]->mo.ModemInfo=="WCDMA")
		{
			countwcdma=countwcdma+1;
		}
		else if(mobi[i]->mo.ModemInfo=="LTE")
		{
			countlte=countlte+1;
		}

	}
	cout<<"Number of phones having wireless technology of type GSM = "<<countgsm<<endl;
	cout<<"Number of phones having wireless technology of type GPRS = "<<countgprs<<endl;
	cout<<"Number of phones having wireless technology of type WCDMA = "<<countwcdma<<endl;
	cout<<"Number of phones having wireless technology of type LTE = "<<countlte<<endl;
}
int Network :: Number_Of_Phones_With_Modeminfo(string str)
{
	count=0;
	for (int i=0; i<NumberOfPhones; i++)
	{
		if(mobi[i]->mo.ModemInfo.compare(str)==0)
		{
			for(int j=0;j<mobi[i]->mo.NumModems;j++)
			{
				if(mobi[i]->si[j].PhoneNumber!=0)
				{
					cout<<"Number of phones with modem info given = "<<mobi[i]->si[j].PhoneNumber<<endl;
				}
				else
				{
					cout<<"no number "<<endl;
					return 0;
				}
			}
		}

	}
	cout<<count<<endl;

}
void  Network :: List_Wireless_Tech_Of_Computer_Platform_From_Manufacturer(string st)
{
	for (int i=0; i<NumberOfPhones;i++)
	{
		if(mobi[i]->get_CManufacturer().compare(st)==0)
		{
			cout<<"List Wireless Tech Of Computer Platform From Manufacturer Given is  "<<mobi[i]->mo.ModemInfo<<endl;
		}
	}
}
int Network :: CheckingForAccess(long long int p)
{
	
	int c=0;
	
	for (int i=0; i<NumberOfPhones;i++)
	{	
	
		for(int j=0;j<mobi[i]->mo.NumModems;j++)
		{
			if(p==(mobi[i]->si[j].PhoneNumber))
			{
			
				c=c+1;
			}

			if(c==1)
			{
				return 1;
				break;
			}
		}
	
	}
	
	
}
int Network :: Finding_Sno_of_Phone(long long int p)
{
	int c=0;

	for (int i=0; i<NumberOfPhones;i++)
	{
		for(int j=0;j<mobi[i]->mo.NumModems;j++)
		{
			if(mobi[i]->si[j].PhoneNumber==p);
			{
				c=c+1;
		
				if(c==1)
				{
					return i;
				}
			}
		}
	}
}

int Network :: Finding_Sno_of_Sim(long long int p)
{
	int c=0;

	for (int i=0; i<NumberOfPhones;i++)
	{
		for(int j=0;j<mobi[i]->mo.NumModems;j++)
		{
			if(mobi[i]->si[j].PhoneNumber==p);
			{
				c=c+1;
		
				if(c==1)
				{
					return j;
				}
			}
		}
	}
}

void Network :: Make_Call(long long int pho,long long int phno)
{
	if(CheckingForAccess(phno)==1)
	{
		Recieve_Call(pho);
	}
	else if(CheckingForAccess(phno)!=1)
	{
		cout<<"CANNOT PLACE A CALL"<<endl;
	}
}
void Network :: Recieve_Call(long long int pn)
{
	int k = Finding_Sno_of_Phone(pn);
	Recieve_Call_N(k);

}

void Network :: Make_Call_N(int no,long long int pr)
{
	int k;
	k=Finding_Sno_of_Sim(no);
	if(mobi[no]->si[k].PhoneNumber)
	{
		if(CheckingForAccess(pr)==1)
		{
			 Recieve_Call_N(no);
		}
		else if(CheckingForAccess(pr)!=1)
		{
			cout<<"CANNOT PLACE A CALL"<<endl;
		}
	}
}
void Network :: Recieve_Call_N(int n)
{
	int j= Finding_Sno_of_Sim(n);
	cout<<mobi[n]->si[j].PhoneNumber<<endl;
	cout<<mobi[n]->Model<<endl;
	cout<<mobi[n]->ma.ManufacturerName<<" ";
	cout<<mobi[n]->ma.Country<<endl;
}
void Network :: Remove_And_Add_Sim(int no1,int no2)
{
	int cc=0;
	string stop;
	long long int phnum;
	for(int j=0;j<mobi[no1]->mo.NumModems;j++)
	{
		if(mobi[no1]->si[j].PhoneNumber!=0 && mobi[no1]->si[j].Operator!=" ")
		{
			stop=mobi[no1]->si[j].Operator;
			phnum=mobi[no1]->si[j].PhoneNumber;
			mobi[no1]->si[j].Operator=" ";
			mobi[no1]->si[j].PhoneNumber=0;
			break;
		}

	}
	for(int j=0;j<mobi[no2]->mo.NumModems;j++)
	{
		if(mobi[no2]->si[j].PhoneNumber==0 && mobi[no2]->si[j].Operator==" ")
		{
			mobi[no2]->si[j].Operator=stop;
			mobi[no2]->si[j].PhoneNumber=phnum;
			break;
		}

	}
	/*for(int j=0;j<5;j++)
	{
		cout<<mobi[j]->si[0].Operator<<" ";
		cout<<mobi[j]->si[0].PhoneNumber;
		//cout<<mobi[j]->si[1].Operator<<" ";
		//cout<<mobi[j]->si[1].PhoneNumber;
		
		cout<<endl;	
	}*/

}