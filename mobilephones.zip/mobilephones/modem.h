#include<string>
#include<vector>
using namespace std;
class Modem
{
public:
	string ModemInfo;
	int NumModems;
	vector <long int> v;
	long int Num;
	void ScanModemDetails();
	
};