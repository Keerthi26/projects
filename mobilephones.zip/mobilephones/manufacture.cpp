#include<iostream>
#include<string>
#include "manufacture.h"
using namespace std;
void Manufacture :: ScanManufactureDetails()
{
	cin>>ManufacturerName>>Country;
}
