#include<iostream>
#include<string>
#include "modem.h"
#include<vector>
using namespace std;
void Modem :: ScanModemDetails()
{
	cin>>ModemInfo>>NumModems;
	for (int i = 0; i < NumModems; i++)
	{
		cin>>Num;
		v.push_back(Num);
	}
}
