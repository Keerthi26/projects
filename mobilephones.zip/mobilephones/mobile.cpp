#include<iostream>
#include<string>
#include "mobile.h"
using namespace std;
void Mobile :: ScanModelDetails()
{
	cin>>Model;
}