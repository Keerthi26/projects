#include<iostream>
#include<string>
#include "featurephone.h"
using namespace std;
