class Smartphone;
class Mobile;
class Network
{
public:
	int countgsm;
	int countgprs;
	int countwcdma;
	int countlte;
	int count;
	int NumberOfPhones;
	char TypeOfPhone;
	int NumberOfSims;
	Mobile mob;	
	Sim s;
	vector <Mobile*> mobi;
	void Add_Phone_To_Network();
	void Remove_And_Add_Sim(int,int);
	int CheckingForAccess(long long int);
	int Finding_Sno_of_Phone(long long int);
	int Finding_Sno_of_Sim(long long int p);
	void Make_Call(long long int,long long int);
	void Recieve_Call(long long int);
	void Make_Call_N(int,long long int);
	void Recieve_Call_N(int);
	void List_Manufacture_Details();
	void List_Wireless_Tech_Of_Computer_Platform_From_Manufacturer(string);
	int Number_Of_Phones_With_Modeminfo(string);
	void Number_Of_Phones_With_Each_Modeminfo();
};