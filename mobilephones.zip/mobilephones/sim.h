#include<string>
using namespace std;
class Sim
{
public:
	string Operator;
	long long int PhoneNumber;
	void ScanSimValues(); 
	
};