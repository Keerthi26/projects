#include<iostream>
#include<string>
#include "sim.h"
using namespace std;
void Sim :: ScanSimValues()
{	
	cin>>Operator>>PhoneNumber;
}