#include<iostream>
#include<string>
#include "smartphone.h"

using namespace std;
void Smartphone::ScanComputerPlatformDetails()
{
	cin>>CManufacturer>>CModelName;
}
string Smartphone::get_CManufacturer()
{
	return CManufacturer;
}
string Smartphone::get_CModelName()
{
	return CModelName;
}
