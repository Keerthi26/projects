#include<string>
using namespace std;
class Manufacture
{
public:
	
	string ManufacturerName;
	string Country;
	void ScanManufactureDetails();
	
};