#include<iostream>
#include<string>
#include<vector>
using namespace std;
#include "smartphone.h"
#include "network.h"
int main()
{
	Network n;
	n.Add_Phone_To_Network();
	n.Make_Call(9876543210,9001234567);
	n.Remove_And_Add_Sim(2,0);
	n.Make_Call_N(3,9001234567);
	n.List_Manufacture_Details();
	n.Number_Of_Phones_With_Modeminfo("LTE");
	n.List_Wireless_Tech_Of_Computer_Platform_From_Manufacturer("Q");
	n.Number_Of_Phones_With_Each_Modeminfo();
return 0;
}
