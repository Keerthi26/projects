#include "manufacture.h"
#include "modem.h"
#include "sim.h"
class Mobile
{
public:
		Manufacture ma;
		Modem mo;
		vector <Sim> si;
		string Model;
		virtual string get_CManufacturer()
		{
			return " ";
		}
		virtual string get_CModelName()
		{
			return " ";
		}
		void ScanModelDetails();
	
};